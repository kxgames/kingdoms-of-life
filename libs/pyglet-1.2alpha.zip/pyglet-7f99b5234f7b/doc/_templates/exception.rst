`{{ objname }}`
=========================================================

.. template exception.rst

.. inheritance-diagram:: {{ fullname }}

Exception defined in :mod:`{{ module }}`

.. currentmodule:: {{ module }}

.. auto{{ objtype }}:: {{ objname }}

