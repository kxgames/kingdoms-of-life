`{{ objname }}` Function
==============================================================

.. template function.rst

Defined in :mod:`{{ module }}`

.. auto{{ objtype }}:: {{ fullname }}

