#!/usr/bin/python
# $Id:$

import os.path
import sys

script_dir = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(script_dir, '..', '..'))
sys.path.insert(0, script_dir)
